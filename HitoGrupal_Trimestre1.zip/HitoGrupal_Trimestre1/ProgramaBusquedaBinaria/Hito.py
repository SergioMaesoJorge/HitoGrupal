def hito(numero):
    numeros=[1,2,3,4,5,6,7,8,9] #Establecemos las variables que vamos a usar
    maximo=len(numeros)-1
    minimo=0
    medio=0

    while minimo <= maximo:
        medio=(maximo+minimo)//2 #El operador // nos devuelve el resultado de la división como un entero
        #La operación sirve para encontrar el elemento del medio de la lista 
        if numeros[medio] < numero: #Si el elemento del medio es menor que nuestro número
            minimo= medio+1 #nuestro nuevo mínimo es el siguiente elemento de la lista

        elif numeros[medio] > numero: #Si el medio es mayor que nuestro número 
            maximo= medio -1 #Nuestro nuevo máximo es el anterior elemento de la lista

        else:
            return medio #En el caso de que nuestro número y el medio coincidan
            #el programa devuelve "medio", que es el índice en el que se
            #encuentra nuestro número
    
    return -1 #Si el elemento no estaba en nuestra lista, devuelve -1

resultado= hito(7)
if resultado == -1:
    print('El número no esta en la lista')
else:
    print(f'El número se encuentra en el índice {resultado}')
